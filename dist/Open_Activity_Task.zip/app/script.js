let count = 0;

function increaseCount(){
    count++;
    document.getElementById('count').innerText = count;
    if(count === 10){
        count = 0;
    }
}

setInterval(increaseCount,1000);